@extends('layouts.layout-admin')
@section('content')
<div class="row">
  <div class="col l12">
    <h4>Welcome Admin</h4>
  </div>
</div>
@endsection
