<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session('status')): ?>
      <div class="row">
        <div class="col s12 l12">
          <div class="card green accent-4">
            <div class="card-content white-text">
              <span class="card-title">Message</span>
              <p><?php echo e(session('status')); ?></p>
            </div>
          </div>
        </div>
      </div>
    <?php endif; ?>
    <div class="row full-height">
      <img src="<?php echo e(asset('img/logo-tagline.png')); ?>" class="responsive-img">
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>