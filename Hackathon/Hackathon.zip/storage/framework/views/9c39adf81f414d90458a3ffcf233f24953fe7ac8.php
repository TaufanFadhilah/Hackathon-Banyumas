<?php $__env->startSection('content'); ?>
<div class="container">
  <?php if(session('status')): ?>
    <div class="row">
      <div class="col s12 l12">
        <div class="card green accent-4">
          <div class="card-content white-text">
            <span class="card-title">Message</span>
            <p><?php echo e(session('status')); ?></p>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
  <div class="row">
    <div class="col l12">
      <table>
        <tr>
          <td>Title</td>
          <td><?php echo e($data->title); ?></td>
        </tr>
        <tr>
          <td>Publisher</td>
          <td><?php echo e($data->User->firstName); ?></td>
        </tr>
        <tr>
          <td>Description</td>
          <td><?php echo e($data->desc); ?></td>
        </tr>
        <tr>
          <td>Price</td>
          <td>Rp. <?php echo e(number_format($data->price)); ?></td>
        </tr>
        <tr>
          <td>Status</td>
          <td>
            <?php if($data->status == 0): ?>
              Ready
            <?php elseif($data->status == 1): ?>
              On Going
            <?php else: ?>
              Done
            <?php endif; ?>
          </td>
        </tr>
        <tr>
          <td>Published at</td>
          <td><?php echo e($data->created_at); ?></td>
        </tr>
        <tr>
          <td>Due Date</td>
          <td><?php echo e($data->dueDate); ?></td>
        </tr>
      </table>
    </div>
    <?php $__currentLoopData = $data->Photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row">
        <div class="col s12 m6 l4">
          <div class="card">
            <div class="card-image">
              <img src="<?php echo e(url('storage/'.$row->path)); ?>">
              <a href="<?php echo e(route('adsPhoto.destroy',['id' => $row->id])); ?>" class="btn-floating halfway-fab waves-effect waves-light red"><i class="material-icons">delete</i></a>
            </div>
          </div>
        </div>
      </div>
      
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="row">
    <h5>List of bidders</h5>
    <ul class="collection">
      <?php $__currentLoopData = $data->Bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="collection-item avatar">
          <img src="<?php echo e(url('storage/'.$row->User->photo)); ?>" alt="" class="circle">
          <span class="title"><?php echo e($row->User->firstName); ?></span>
          <p>Rp. <?php echo e(number_format($row->price)); ?> <br>
             <?php echo e($row->note); ?>

          </p>
          <?php if(isset($data->Transaction)): ?>
            <?php if($data->Transaction->bidId == $row->id): ?>
              <td>Choosen</td>
            <?php else: ?>
              <td></td>
            <?php endif; ?>
          <?php elseif($data->userId == Auth::id()): ?>
              <td><a href="<?php echo e(route('transaction.store',['bidId' => $row->id,'advertisementId' => $data->id])); ?>"  class="secondary-content"><button class="btn green"><i class="material-icons">check</i></button></a></td>
          <?php endif; ?>
          
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    
  </div>
  
  <?php if($data->userId == Auth::id()): ?>
    <div class="row">
      <div class="col l6">
        <a class="waves-effect waves-light btn amber modal-trigger full-width" href="#edit"><i class="material-icons left">edit</i>Edit</a>
      </div>
      <div class="col l6">
        <form class="" action="<?php echo e(route('advertisement.destroy',['advertisement' => $data->id])); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <input type="hidden" name="_method" value="delete">
          <button type="submit" class="btn red full-width"><i class="material-icons left">delete</i>Delete</button>
        </form>
      </div>
    </div>
    
    <?php else: ?>
      
      <div class="row">
        <div class="col l12 s12">
          <?php if($data->checkBid($data->id,Auth::id()) == 0 && !isset($data->Transaction)): ?>
            <button data-target="bid" class="btn modal-trigger blue">Click here to bidding!</button>
          <?php else: ?>
            <?php if(isset($data->Transaction)): ?>
              <p>Bid has been closed</p>
            <?php else: ?>
              <p>Youre already set the bid</p>
            <?php endif; ?>
          <?php endif; ?>

        </div>
      </div>

      
      <div id="bid" class="modal modal-fixed-footer">
        <div class="modal-content">
          <h4>Start Bidding</h4>
          <form action="<?php echo e(route('bid.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="userId" value="<?php echo e(Auth::id()); ?>">
            <input type="hidden" name="advertisementId" value="<?php echo e($data->id); ?>">
            <div class="input-field col l12">
              <input type="number" name="price" id="price" class="validate" required>
              <label for="price">Bid Price</label>
              <?php if($errors->has('price')): ?>
                  <small class="red-text"><?php echo e($errors->first('price')); ?></small>
              <?php endif; ?>
            </div>
            <div class="input-field col l12 s12">
              <textarea name="note" class="materialize-textarea" id="note" required></textarea>
              <label for="note">Note</label>
              <?php if($errors->has('note')): ?>
                  <small class="red-text"><?php echo e($errors->first('note')); ?></small>
              <?php endif; ?>
            </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn blue">Save</button>
        </div>
        </form>
      </div>
      

      
  <?php endif; ?>


</div>

<div id="edit" class="modal modal-fixed-footer">
    <div class="modal-content">
      <h4>Edit Advertisement</h4>
      <form action="<?php echo e(route('advertisement.update',['advertisement' => $data->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="_method" value="PUT">
        <input type="hidden" name="userId" value="<?php echo e(Auth::id()); ?>">
        <input type="hidden" name="status" value="<?php echo e($data->status); ?>">
        <div class="input-field col l12 s12">
          <input type="text" name="title" id="title" class="validate" value="<?php echo e($data->title); ?>" required>
          <label for="title">Title</label>
          <?php if($errors->has('title')): ?>
              <small class="red-text"><?php echo e($errors->first('title')); ?></small>
          <?php endif; ?>
        </div>
        <div class="input-field col l12 s12">
          <textarea name="desc" class="materialize-textarea" id="desc"> <?php echo e($data->desc); ?></textarea>
          <label for="desc">Description</label>
          <?php if($errors->has('desc')): ?>
              <small class="red-text"><?php echo e($errors->first('desc')); ?></small>
          <?php endif; ?>
        </div>
        <div class="input-field col l6 s12">
          <input type="number" name="price" id="price" class="validate" value="<?php echo e($data->price); ?>" required>
          <label for="price">Price</label>
          <?php if($errors->has('price')): ?>
              <small class="red-text"><?php echo e($errors->first('price')); ?></small>
          <?php endif; ?>
        </div>
        <div class="input-field col l6 s12">
          <input type="date" name="dueDate" id="dueDate" value="<?php echo e($data->dueDate); ?>" class="datepicker" required>
          <label for="dueDate">Due Date</label>
          <?php if($errors->has('dueDate')): ?>
              <small class="red-text"><?php echo e($errors->first('dueDate')); ?></small>
          <?php endif; ?>
        </div>
        <div class="file-field input-field col l12 s12">
          <div class="btn amber">
            <span><i class="material-icons">add_a_photo</i></span>
            <input name="photos[]" type="file" multiple >
          </div>
          <div class="file-path-wrapper">
            <input class="file-path validate" type="text" placeholder="Upload one or more photos">
          </div>
          <?php if($errors->has('photos')): ?>
              <small class="red-text"><?php echo e($errors->first('photos')); ?></small>
          <?php endif; ?>
        </div>
    </div>
    <div class="modal-footer">
      <button type="submit" class="btn amber full-width">Save</button>
    </div>
    </form>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script type="text/javascript">
  $(document).ready(function(){
    $('.materialboxed').materialbox();
    $('.modal').modal();
    $('.datepicker').pickadate({
     selectMonths: true, // Creates a dropdown to control month
     selectYears: 15, // Creates a dropdown of 15 years to control year,
     today: 'Today',
     clear: 'Clear',
     close: 'Ok',
     closeOnSelect: false, // Close upon selecting a date,
     format: 'yyyy-mm-dd'
   });
  });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>