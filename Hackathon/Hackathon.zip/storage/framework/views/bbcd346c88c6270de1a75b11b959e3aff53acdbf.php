<?php $__env->startSection('content'); ?>
<div class="container full-height">
  <div class="row">
    <h4>Create Adv</h4>
  </div>
  <div class="row">
    <form class="" action="<?php echo e(route('adv.store')); ?>" method="post" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <input type="hidden" name="userId" value="<?php echo e(Auth::id()); ?>">
      <input type="hidden" name="status" value="0">
      <div class="input-field col l12 s12">
        <input type="text" name="title" id="title" class="validate" required>
        <label for="title">Title</label>
        <?php if($errors->has('title')): ?>
            <small class="red-text"><?php echo e($errors->first('title')); ?></small>
        <?php endif; ?>
      </div>
      <div class="input-field col l12 s12">
        <textarea name="desc" class="materialize-textarea" id="desc" required></textarea>
        <label for="desc">Description</label>
        <?php if($errors->has('desc')): ?>
            <small class="red-text"><?php echo e($errors->first('desc')); ?></small>
        <?php endif; ?>
      </div>
      <div class="input-field col l6 s12">
        <input type="number" name="price" id="price" class="validate" required>
        <label for="price">Price</label>
        <?php if($errors->has('price')): ?>
            <small class="red-text"><?php echo e($errors->first('price')); ?></small>
        <?php endif; ?>
      </div>
      <div class="input-field col l6 s12">
        <input type="date" name="dueDate" id="dueDate" class="datepicker" required>
        <label for="dueDate">Due Date</label>
        <?php if($errors->has('dueDate')): ?>
            <small class="red-text"><?php echo e($errors->first('dueDate')); ?></small>
        <?php endif; ?>
      </div>
      <div class="file-field input-field col l12 s12">
        <div class="btn amber">
          <span><i class="material-icons">add_a_photo</i></span>
          <input name="photos[]" type="file" multiple required>
        </div>
        <div class="file-path-wrapper">
          <input class="file-path validate" type="text" placeholder="Upload one or more photos">
        </div>
        <?php if($errors->has('photos')): ?>
            <small class="red-text"><?php echo e($errors->first('photos')); ?></small>
        <?php endif; ?>
      </div>
      <div class="input-field col l12 s12">
        <button type="submit" class="btn amber full-width">Create</button>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
  <script type="text/javascript">
    $('.datepicker').pickadate({
     selectMonths: true, // Creates a dropdown to control month
     selectYears: 15, // Creates a dropdown of 15 years to control year,
     today: 'Today',
     clear: 'Clear',
     close: 'Ok',
     closeOnSelect: false, // Close upon selecting a date,
     format: 'yyyy-mm-dd'
   });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>