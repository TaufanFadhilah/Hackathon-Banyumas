<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col l12">
    <h5>List Advertisement</h5>
    <table class="table bordered">
      <tr>
        <th>No.</th>
        <th>Title</th>
        <th>Price</th>
        <th>Due Date</th>
        <th>Detail</th>
      </tr>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$index); ?></td>
          <td><?php echo e($row->title); ?></td>
          <td><?php echo e($row->price); ?></td>
          <td><?php echo e($row->dueDate); ?></td>
          <td><a href="<?php echo e(route('admin.advertisementShow',['advertisement' => $row->id])); ?>"><button class="btn blue"><i class="material-icons">zoom_out_map</i></button></a></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>