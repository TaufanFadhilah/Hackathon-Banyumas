<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/materialize.min.css')); ?>"  media="screen,projection"/>
      <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
      <!-- CSRF Token -->
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <?php echo $__env->yieldPushContent('css'); ?>
    </head>

    <body>
      <div class="container">
        <div class="row">
          <div class="col l12">
            <h1 class="green-text center">Sorry, youre not admin.</h1>
          </div>
        </div>
      </div>
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
      <script type="text/javascript" src="<?php echo e(asset('js/materialize.min.js')); ?>"></script>
      <script type="text/javascript">
        $(".button-collapse").sideNav();
      </script>
      <?php echo $__env->yieldPushContent('js'); ?>
    </body>
  </html>
