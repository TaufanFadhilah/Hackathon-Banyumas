<?php $__env->startSection('content'); ?>
<div class="container-fluid full-height">
  <div class="row">
    <div class="col l7 hide-on-small-only full-height">
      <img src="<?php echo e(asset('img/logo-tagline.jpg')); ?>" style="max-height: 500px">
    </div>
    <div class="col l5 s12">
      <div class="row">
        <div class="col l12 s12 center">
          <h3>Login</h3>
        </div>
      </div>
      <form action="<?php echo e(route('login')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="row">
          <div class="input-field col s12">
            <input name="email" id="email" type="email" class="validate" required>
            <label for="email">Email</label>
            <?php if($errors->has('email')): ?>
                <small class="red-text"><?php echo e($errors->first('email')); ?></small>
            <?php endif; ?>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12">
            <input name="password" id="password" type="password" class="validate" required maxlength="12">
            <label for="password">Password</label>
            <?php if($errors->has('password')): ?>
                <small class="red-text"><?php echo e($errors->first('password')); ?></small>
            <?php endif; ?>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12">
            <a href="<?php echo e(route('register')); ?>">Haven't have account</a> <br>
            <a href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
          </div>
        </div>
        <div class="row center">
          <div class="input-field col s12">
            <button type="submit" class="btn amber" style="width: 100%">Sign In!</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>