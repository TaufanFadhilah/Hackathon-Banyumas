<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col l12">
    <h5><?php echo e($title); ?></h5>
    <table class="table bordered">
      <tr>
        <th>No.</th>
        <th>Advertisement</th>
        <th>Instagram</th>
        <th>Price</th>
        <th><?php echo e($action); ?></th>
      </tr>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$index); ?></td>
          <td><a href="<?php echo e(route('admin.advertisementShow',['advertisement' => $row->Advertisement->id])); ?>"><?php echo e($row->Advertisement->title); ?></a></td>
          <td><a href="<?php echo e($row->Bid->User->Instagram->link); ?>" target="_blank"><?php echo e($row->Bid->User->firstName); ?> <?php echo e($row->Bid->User->lastName); ?></a></td>
          <td>Rp. <?php echo e(number_format($row->Bid->price)); ?></td>
          <?php if($row->status == 3): ?>
            <td>
              <a href="<?php echo e(route('bid.update',['id' => $row->id,'status' => 4])); ?>"><button class="btn blue"><i class="material-icons">payment</i></button></a>
            </td>
          <?php endif; ?>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>