<nav class="green">
    <div class="nav-wrapper">
      <a href="<?php echo e(route('home')); ?>" class="brand-logo"><img src="<?php echo e(asset('img/logo-app.png')); ?>" class="responsive-img nav-logo" style="padding-bottom: 10px"></a>
      <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
      <ul class="right hide-on-med-and-down">
        <li><a class="dropdown-button" href="#!" data-activates="ads">Ads <i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="bids">Bids <i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="transaction">Transaction <i class="material-icons right">arrow_drop_down</i></a></li>
        <li>
          <a href="<?php echo e(route('logout')); ?>"
              onclick="event.preventDefault();
                       document.getElementById('logout-form').submit();">
              Logout  <i class="material-icons right">exit_to_app</i>
          </a>

          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo e(csrf_field()); ?>

          </form>
        </li>
        <li><a href="<?php echo e(route('user.edit')); ?>"><i class="material-icons">person</i></a></li>
      </ul>
      <ul class="side-nav" id="mobile-demo">
        <li><a href="sass.html">Ads</a></li>
        <li>
          <a href="<?php echo e(route('logout')); ?>"
              onclick="event.preventDefault();
                       document.getElementById('logout-form').submit();">
              Logout
          </a>

          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo e(csrf_field()); ?>

          </form>
        </li>
      </ul>
    </div>
</nav>

<ul id="ads" class="dropdown-content">
  <li><a href="<?php echo e(route('advertisement.create')); ?>">Create Ads</a></li>
  <li><a href="<?php echo e(route('advertisement.mine')); ?>">My Ads</a></li>
  <li><a href="<?php echo e(route('advertisement.index')); ?>">Looking for Ads</a></li>
</ul>


<ul id="bids" class="dropdown-content">
  <li><a href="<?php echo e(route('bid.mine')); ?>">Bids</a></li>
  <li><a href="<?php echo e(route('bid.choosen')); ?>">Choosen Bids</a></li>
  <li><a href="<?php echo e(route('bid.ongoing')); ?>">On going task</a></li>
  <li><a href="<?php echo e(route('bid.done')); ?>">Done task</a></li>
</ul>


<ul id="transaction" class="dropdown-content">
  <li><a href="<?php echo e(route('bid.confirmation')); ?>">Accepted Task</a></li>
</ul>

