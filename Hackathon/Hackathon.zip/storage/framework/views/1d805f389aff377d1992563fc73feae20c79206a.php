<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col l12">
    <table>
      <tr>
        <td>Title</td>
        <td><?php echo e($data->title); ?></td>
      </tr>
      <tr>
        <td>Publisher</td>
        <td><?php echo e($data->User->firstName); ?></td>
      </tr>
      <tr>
        <td>Description</td>
        <td><?php echo e($data->desc); ?></td>
      </tr>
      <tr>
        <td>Price</td>
        <td>Rp. <?php echo e(number_format($data->price)); ?></td>
      </tr>
      <tr>
        <td>Status</td>
        <td>
          <?php if($data->status == 0): ?>
            Ready
          <?php elseif($data->status == 1): ?>
            On Going
          <?php else: ?>
            Done
          <?php endif; ?>
        </td>
      </tr>
      <tr>
        <td>Published at</td>
        <td><?php echo e($data->created_at); ?></td>
      </tr>
      <tr>
        <td>Due Date</td>
        <td><?php echo e($data->dueDate); ?></td>
      </tr>
    </table>
  </div>
</div>
<div class="row">
  <?php $__currentLoopData = $data->Photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col l4 s12">
      <img src="<?php echo e(url('storage/'.$row->path)); ?>" class="materialboxed">
      <?php if($data->userId == Auth::id()): ?>
        <a href="<?php echo e(route('adsPhoto.destroy',['id' => $row->id])); ?>"><button class="btn red"><i class="material-icons">delete</i></button></a>
      <?php endif; ?>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="row">
  <h5>List of bidders</h5>
  <table class="table bordered">
    <tr>
      <th>No.</th>
      <th>Account</th>
      <th>Price</th>
      <th>Note</th>
      <th>Choose</th>
    </tr>
    <?php $__currentLoopData = $data->Bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e(++$index); ?></td>
        <td><a href="<?php echo e($row->User->Instagram->link); ?>" target="_blank"><?php echo e($row->User->firstName); ?> <?php echo e($row->User->lastName); ?></a></td>
        <td>Rp. <?php echo e(number_format($row->price)); ?></td>
        <td><?php echo e($row->note); ?></td>
        <?php if(isset($data->Transaction)): ?>
          <?php if($data->Transaction->bidId == $row->id): ?>
            <td>Choosen</td>
          <?php else: ?>
            <td></td>
          <?php endif; ?>
        <?php endif; ?>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>