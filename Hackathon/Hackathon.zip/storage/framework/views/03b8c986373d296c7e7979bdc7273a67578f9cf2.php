<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col l12">
    <h5>List User</h5>
    <table class="table bordered">
      <tr>
        <th>No.</th>
        <th>Name</th>
        <th>Email</th>
        <th>Instagram</th>
        <th>Photo</th>
      </tr>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$index); ?></td>
          <td><?php echo e($row->firstName); ?></td>
          <td><?php echo e($row->email); ?></td>
          <td><a href="<?php echo e($row->Instagram->link); ?>" target="_blank"><?php echo e($row->Instagram->link); ?></a></td>
          <td><img class="responsive-img circle" src="<?php echo e(url('storage/'.$row->photo)); ?>" style="max-height: 100px"></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>