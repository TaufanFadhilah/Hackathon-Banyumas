<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row full-height">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col l4 s12">
        <div class="card">
          <div class="card-image">
            <img src="<?php echo e(url('storage/'.$row->Photos->first()->path)); ?>" style="max-height: 200px">
            <span class="card-title"><?php echo e($row->title); ?></span>
          </div>
          <div class="card-content">
            <p><?php echo e(str_limit($row->desc,50)); ?></p>
            <br>
            <p>Rp. <?php echo e(number_format($row->price)); ?></p>
          </div>
          <div class="card-action">
            <a href="<?php echo e(route('advertisement.show',['advertisement' => $row->id])); ?>">More...</a>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="row">
    <div class="col l12 center">
      <?php echo e($data->links('vendor.pagination.default')); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>