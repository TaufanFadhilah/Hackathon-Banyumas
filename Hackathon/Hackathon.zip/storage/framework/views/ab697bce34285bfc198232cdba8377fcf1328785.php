<?php $__env->startSection('content'); ?>
<div class="container">
  <?php if(session('status')): ?>
    <div class="row">
      <div class="col s12 l12">
        <div class="card green accent-4">
          <div class="card-content white-text">
            <span class="card-title">Message</span>
            <p><?php echo e(session('status')); ?></p>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
  <div class="row">
    <div class="col l12 s12">
      <h4><?php echo e($title); ?></h4>
      <table class="table bordered">
        <tr>
          <th>No.</th>
          <th>Advertisement</th>
          <th>Price</th>
          <th>Due Date</th>
          <?php if(!isset($bid)): ?>
            <th><?php echo e($action); ?></th>
          <?php endif; ?>
        </tr>
        <?php if(isset($bid)): ?>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e(++$index); ?></td>
              <td><a href="<?php echo e(route('advertisement.show',['advertisement' => $row->Advertisement->id])); ?>"><?php echo e($row->Advertisement->title); ?></a></td>
              <td>Rp. <?php echo e(number_format($row->price)); ?></td>
              <td><?php echo e($row->Advertisement->dueDate); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e(++$index); ?></td>
              <td><a href="<?php echo e(route('advertisement.show',['advertisement' => $row->Advertisement->id])); ?>"><?php echo e($row->Advertisement->title); ?></a></td>
              <td>Rp. <?php echo e(number_format($row->Bid->price)); ?></td>
              <td><?php echo e($row->Advertisement->dueDate); ?></td>
              <td>
                <?php if($row->status == 0): ?>
                  <a href="<?php echo e(route('bid.update',['id' => $row->id, 'status' => 1])); ?>"><button class="btn blue"> <i class="material-icons">check</i></button></a>
                <?php elseif($row->status == 1): ?>
                  <a class="waves-effect waves-light btn blue modal-trigger" href="#confirmation"><i class="material-icons">assessment</i></a>
                  <div id="confirmation" class="modal">
                    <div class="modal-content">
                      <h4>Confirmation</h4>
                      <form action="<?php echo e(route('bid.updateConfirmation')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php echo e($row->id); ?>">
                        <div class="file-field input-field">
                          <div class="btn amber">
                            <i class="tiny material-icons">add_a_photo</i>
                            <input name="photo" type="file" required>
                          </div>
                          <div class="file-path-wrapper">
                            <input class="file-path validate" type="text" placeholder="Photo">
                          </div>
                          <?php if($errors->has('photo')): ?>
                              <small class="red-text"><?php echo e($errors->first('photo')); ?></small>
                          <?php endif; ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                      <button type="submit" class="btn amber">Save</button>
                    </div>
                    </form>
                  </div>
                <?php elseif($row->status == 2): ?>
                  <a href="<?php echo e(route('bid.update',['id' => $row->id, 'status' => 3])); ?>"><button class="btn blue"> <i class="material-icons">check</i></button></a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
  <script type="text/javascript">
    $(document).ready(function(){
    $('.modal').modal();
  });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>